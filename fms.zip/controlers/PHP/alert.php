<?php
function success_alert($message)
{
}
