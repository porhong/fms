<?php
include "user_controler.php";
logout();
